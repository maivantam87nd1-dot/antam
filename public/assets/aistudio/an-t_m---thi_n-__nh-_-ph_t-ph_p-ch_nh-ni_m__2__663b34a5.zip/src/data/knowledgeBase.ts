import { KnowledgeChunk } from '../types';

export const VERIFIED_KNOWLEDGE_BASE: KnowledgeChunk[] = [
  {
    id: 'kb-four-noble-truths',
    documentTitle: 'Kinh Chuyển Pháp Luân (Dhammacakkappavattana Sutta)',
    tradition: 'Phật giáo Nguyên thủy (Nikāya - Tương Ưng Bộ V)',
    source: 'Đại Tạng Kinh Pāli, bản dịch HT. Thích Minh Châu',
    chapter: 'Tứ Diệu Đế - Bốn Chân Lý Cao Thượng',
    keywords: ['tứ diệu đế', 'bốn chân lý', 'khổ đế', 'tập đế', 'diệt đế', 'đạo đế', 'dukkha', 'nguyên nhân khổ'],
    content: `Tứ Diệu Đế (Cattāri Ariyasaccāni) là giáo lý nền tảng đầu tiên Đức Phật thuyết giảng tại vườn Lộc Uyển:
1. Khổ đế (Dukkha Sacca): Chân lý về sự bất toàn và khổ đau trong đời sống (sinh, già, bệnh, chết, xa lìa người thân yêu, gặp gỡ người oán ghét, mong cầu không được, và sự chấp thủ vào năm uẩn).
2. Tập đế (Samudaya Sacca): Chân lý về nguyên nhân đưa đến khổ đau, cội rễ chính là ái dục (taṇhā - khát khao bám víu), tham sân và si mê vô minh.
3. Diệt đế (Nirodha Sacca): Chân lý về sự chấm dứt khổ đau - trạng thái Niết Bàn (Nibbāna), khi mọi bám víu và ảo tưởng được dập tắt hoàn toàn.
4. Đạo đế (Magga Sacca): Con đường tám nhánh (Bát Chánh Đạo) dẫn đến sự dập tắt khổ đau.`
  },
  {
    id: 'kb-eightfold-path',
    documentTitle: 'Kinh Chuyển Pháp Luân & Kinh Phân Biệt Thánh Đế',
    tradition: 'Phật giáo Nguyên thủy (Trung Bộ Kinh 141)',
    source: 'Đại Tạng Kinh Pāli, bản dịch HT. Thích Minh Châu',
    chapter: 'Bát Chánh Đạo - Con Đường Tám Nhánh',
    keywords: ['bát chánh đạo', 'chánh kiến', 'chánh tư duy', 'chánh ngữ', 'chánh nghiệp', 'chánh mạng', 'chánh tinh tấn', 'chánh niệm', 'chánh định', 'con đường giải thoát'],
    content: `Bát Chánh Đạo (Ariya Aṭṭhaṅgika Magga) chia làm 3 nhóm Giới - Định - Tuệ:
- Nhóm Tuệ (Paññā):
  1. Chánh kiến (Sammā-diṭṭhi): Thấy biết đúng đắn về nhân quả, duyên khởi và bốn chân lý thánh đế.
  2. Chánh tư duy (Sammā-saṅkappa): Suy nghĩ không tham lam, không oán hận, nuôi dưỡng tâm buông xả và từ bi.
- Nhóm Giới (Sīla):
  3. Chánh ngữ (Sammā-vācā): Lời nói chân thật, hòa ái, xây dựng, tránh nói dối, nói thêu dệt và nói lời độc địa.
  4. Chánh nghiệp (Sammā-kammanta): Hành động thanh tịnh, không sát sinh, không trộm cắp, không tà hạnh.
  5. Chánh mạng (Sammā-ājīva): Nuôi sống bản thân bằng nghề nghiệp chân chính, không gây hại cho sinh linh khác.
- Nhóm Định (Samādhi):
  6. Chánh tinh tấn (Sammā-vāyāma): Nỗ lực ngăn ngừa điều ác, phát triển điều thiện lành.
  7. Chánh niệm (Sammā-sati): Tỉnh giác có mặt trọn vẹn nơi thân, thọ, tâm, pháp trong hiện tại.
  8. Chánh định (Sammā-samādhi): Tập trung tâm ý an tịnh, dứt bỏ tán loạn, an trú thiền định.`
  },
  {
    id: 'kb-heart-sutra',
    documentTitle: 'Bát Nhã Ba La Mật Đa Tâm Kinh (Prajñāpāramitā Hṛdaya Sūtra)',
    tradition: 'Phật giáo Đại thừa (Mahāyāna)',
    source: 'Đại Tạng Kinh Đại Chính Tân Tu, bản dịch HT. Thích Nhất Hạnh & HT. Thích Trí Quang',
    chapter: 'Cốt tủy Trí tuệ Bát Nhã & Tính Không',
    keywords: ['bát nhã', 'tâm kinh', 'sắc tức thị không', 'ngũ uẩn giai không', 'không bất dị sắc', 'vô quái ngại', 'quán tự tại', 'tính không', 'sunyata'],
    content: `Bát Nhã Tâm Kinh chỉ rõ tuệ giác tối thượng:
- "Chiếu kiến ngũ uẩn giai không, độ nhất thiết khổ ách": Soi thấy năm uẩn (sắc thân, cảm thọ, tri giác, tâm hành, nhận thức) đều duyên khởi, không có tự tính độc lập bất biến (Không - Śūnyatā). Thấy được điều này liền vượt qua mọi khổ đau sợ hãi.
- "Sắc bất dị không, không bất dị sắc; sắc tức thị không, không tức thị sắc": Vạn vật hiện hữu không tách rời tính không, và tính không biểu hiện qua vạn vật. Giống như sóng là nước, nước là sóng.
- "Tâm vô quái ngại, vô hữu khủng bố, viễn ly điên đảo mộng tưởng, cứu cánh Niết Bàn": Khi tâm không còn vướng mắc bám víu vào các tướng giả hợp, con người tự tại thoát khỏi mọi hoang mang ảo tưởng, đạt sự an lạc tối hậu.`
  },
  {
    id: 'kb-anapanasati',
    documentTitle: 'Kinh Quán Niệm Hơi Thở (Ānāpānasati Sutta)',
    tradition: 'Phật giáo Nguyên thủy (Trung Bộ Kinh số 118)',
    source: 'Đại Tạng Kinh Pāli, bản dịch HT. Thích Minh Châu',
    chapter: '16 Đề mục Hơi thở Chánh niệm',
    keywords: ['hơi thở', 'quán niệm hơi thở', 'anapanasati', 'thở vào', 'thở ra', 'an tịnh thân hành', '16 đề mục'],
    content: `Đức Phật chỉ dạy phương pháp dùng hơi thở làm chiếc neo cho tâm:
- Bốn hơi thở đầu (Quán Thân):
  1. Thở vào dài, biết tôi thở vào dài. Thở ra dài, biết tôi thở ra dài.
  2. Thở vào ngắn, biết tôi thở vào ngắn. Thở ra ngắn, biết tôi thở ra ngắn.
  3. Cảm giác toàn thân, tôi thở vào. Cảm giác toàn thân, tôi thở ra.
  4. An tịnh thân hành, tôi thở vào. An tịnh thân hành, tôi thở ra.
- Nguyên lý: Không gượng ép, không thở cưỡng bức, chỉ nhận biết hơi thở tự nhiên như nó đang trôi chảy.`
  },
  {
    id: 'kb-great-compassion-mantra',
    documentTitle: 'Đại Bi Thần Chú (Mahā Karuṇā Dhāraṇī)',
    tradition: 'Mật tông Đại thừa (Esoteric Mahāyāna)',
    source: 'Kinh Thiên Thủ Thiên Nhãn Quán Thế Âm Bồ Tát Quảng Đại Viên Mãn Vô Ngại Đại Bi Tâm Đà La Ni',
    chapter: '84 Câu Chân Ngôn và Tâm Từ Bi Cứu Khổ',
    keywords: ['chú đại bi', 'đại bi thần chú', 'quán thế âm', 'nam mô hắc ra đát na', 'từ bi cứu khổ', 'chân ngôn'],
    content: `Chú Đại Bi gồm 84 câu chân ngôn xưng tán hạnh nguyện và đức tướng từ bi vô biên của Bồ Tát Quán Thế Âm:
- Ý nghĩa: Chân ngôn khơi dậy 10 tâm hạnh: tâm bình đẳng, tâm đại từ bi, tâm cung kính, tâm khiêm nhường, tâm không tham sân, tâm không ngăn ngại, tâm quán chiếu tính không.
- Thực hành: Người trì tụng chú Đại Bi lắng lòng thanh tịnh, quán chiếu âm thanh cứu khổ của cuộc đời, hồi hướng năng lượng an lành và chữa lành vết thương tinh thần cho tự thân và tha nhân.`
  },
  {
    id: 'kb-metta-sutta',
    documentTitle: 'Kinh Từ Bi (Karaṇīya Mettā Sutta)',
    tradition: 'Phật giáo Nguyên thủy (Tiểu Bộ Kinh - Sutta Nipāta 1.8)',
    source: 'Bản dịch Pāli của HT. Thích Minh Châu & Thiền sư Nhất Hạnh',
    chapter: 'Nuôi dưỡng Tâm Từ Vô Lượng',
    keywords: ['kinh từ bi', 'metta', 'tâm từ', 'lòng trắc ẩn', 'nguyện cho muôn loài', 'bình an hạnh phúc'],
    content: `Kinh Từ Bi dạy cách mở rộng lòng thương yêu không biên giới:
- "Như một người mẹ đang bảo vệ đứa con duy nhất của mình bằng cả mạng sống, hãy nuôi dưỡng một trái tim từ bi không giới hạn đối với tất cả muôn loài."
- Nguyện ước: Nguyện cho khắp muôn loài hữu tình, dù yếu ớt hay mạnh mẽ, to lớn hay bé nhỏ, đều được bình an, mạnh khỏe và thoát khỏi mọi nỗi sợ hãi oán thù.`
  },
  {
    id: 'kb-three-marks-existence',
    documentTitle: 'Kinh Vô Thường & Kinh Vô Ngã Tướng (Anattalakkhaṇa Sutta)',
    tradition: 'Phật giáo Nguyên thủy & Đại thừa',
    source: 'Tương Ưng Bộ III & Tạp A Hàm',
    chapter: 'Tam Pháp Ấn: Vô Thường, Khổ, Vô Ngã',
    keywords: ['vô thường', 'vô ngã', 'khổ', 'tam pháp ấn', 'anicca', 'anatta', 'dukkha', 'buông bỏ chấp thủ'],
    content: `Tam Pháp Ấn (Ti-lakkhaṇa) là 3 dấu ấn thực tại của vạn pháp:
1. Vô thường (Anicca): Mọi sự vật hiện tượng có điều kiện tạo thành đều biến dịch, sinh khởi rồi hoại diệt trong từng sát na, không có gì đứng yên mãi mãi.
2. Khổ (Dukkha): Bất cứ thứ gì vô thường mà tâm ta bám víu coi là thường hằng đều đem lại sự bất an và thất vọng.
3. Vô ngã (Anattā): Không có một cái 'Tôi' hay 'Của Tôi' độc lập, bất biến nằm ngoài sự tương tác duyên khởi của ngũ uẩn. Thấy rõ vô ngã là chìa khóa để buông bỏ khổ đau.`
  },
  {
    id: 'kb-kamma-and-rebirth',
    documentTitle: 'Kinh Pháp Cú (Dhammapada - Kệ 1 & 2)',
    tradition: 'Phật giáo Nguyên thủy (Tiểu Bộ Kinh)',
    source: 'Bản dịch HT. Thích Minh Châu',
    chapter: 'Luật Nhân Quả và Tâm Dẫn Đầu',
    keywords: ['nhân quả', 'nghiệp', 'kamma', 'nghiệp báo', 'kinh pháp cú', 'ý dẫn đầu các pháp', 'gieo nhân gặt quả'],
    content: `Nguyên lý Nghiệp báo (Kamma - Vipāka):
- Kệ 1: "Ý dẫn đầu các pháp, Ý làm chủ, ý tạo. Nếu với ý ô nhiễm, Nói lên hay hành động, Khổ não bước theo sau, Như xe chân vật kéo."
- Kệ 2: "Ý dẫn đầu các pháp, Ý làm chủ, ý tạo. Nếu với ý thanh tịnh, Nói lên hay hành động, An lạc bước theo sau, Như bóng không rời hình."
- Bài học: Số phận không phải do thần linh định đoạt, mà được dệt nên bởi từng suy nghĩ, lời nói và hành vi có ý thức của mỗi chúng ta.`
  },
  {
    id: 'kb-mangal-sutta',
    documentTitle: 'Kinh Điềm Lành / Kinh Phước Đức (Maṅgala Sutta)',
    tradition: 'Phật giáo Nguyên thủy (Tiểu Tụng 5)',
    source: 'Bản dịch HT. Thích Minh Châu',
    chapter: '38 Điềm Lành Hạnh Phúc Đích Thực',
    keywords: ['kinh phước đức', 'mangala sutta', 'hạnh phúc', 'phúc lành', 'tâm không lay chuyển', 'tiếp xúc việc đời'],
    content: `Kinh Phước Đức chỉ ra lối sống đưa đến chân hạnh phúc:
- Không kết bạn cùng kẻ ác, thân cận bậc hiền trí, phụng dưỡng cha mẹ, chăm sóc gia đình, sống đời chánh mạng, bố thí rộng rãi, khiêm tốn biết ơn.
- Đỉnh cao hạnh phúc: "Tiếp xúc với việc đời, tâm không hề lay động, không sầu não, không dính mắc, thanh thản và bình an, đó là phúc lành cao nhất."`
  },
  {
    id: 'kb-samatha-vipassana',
    documentTitle: 'Kinh Niệm Xứ (Satipaṭṭhāna Sutta)',
    tradition: 'Phật giáo Nguyên thủy & Trúc Lâm Yên Tử',
    source: 'Trung Bộ Kinh số 10',
    chapter: 'Thiền Định: Thiền Chỉ (Samatha) và Thiền Quán (Vipassanā)',
    keywords: ['thiền chỉ', 'thiền quán', 'samatha', 'vipassana', 'tứ niệm xứ', 'tỉnh thức', 'nhận diện thực tại'],
    content: `Hai đôi cánh của Thiền Phật giáo:
- Thiền Chỉ (Samatha): Định tâm vào một đối tượng duy nhất (như hơi thở, câu niệm, hình ảnh hoa sen) để lắng đọng tạp niệm, đạt trạng thái nhất tâm và khinh an.
- Thiền Quán (Vipassanā): Sử dụng tâm đã an tịnh để quán chiếu bản chất thực của thân tâm (vô thường, duyên khởi, vô ngã), từ đó phát khởi tuệ giác đoạn trừ gốc rễ vô minh.
- Trong đời sống: Chỉ là dừng lại (Stop), Quán là nhìn sâu (Look deeply) để hiểu và thương.`
  }
];

// Semantic keyword & token retrieval engine for RAG
export function retrieveKnowledgeChunks(query: string, maxResults = 3): KnowledgeChunk[] {
  if (!query || !query.trim()) return VERIFIED_KNOWLEDGE_BASE.slice(0, maxResults);

  const normalized = query.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  const rawWords = query.toLowerCase().split(/\s+/).filter(w => w.length > 1);

  const scored = VERIFIED_KNOWLEDGE_BASE.map(chunk => {
    let score = 0;
    const chunkTitle = chunk.documentTitle.toLowerCase();
    const chunkChapter = (chunk.chapter || '').toLowerCase();
    const chunkContent = chunk.content.toLowerCase();
    const chunkKeywords = chunk.keywords.map(k => k.toLowerCase());

    // Keyword exact check
    chunkKeywords.forEach(k => {
      if (normalized.includes(k) || query.toLowerCase().includes(k)) {
        score += 15;
      }
    });

    // Title / Chapter match
    rawWords.forEach(word => {
      if (chunkTitle.includes(word)) score += 8;
      if (chunkChapter.includes(word)) score += 6;
      if (chunkContent.includes(word)) score += 2;
    });

    return { chunk, score };
  });

  scored.sort((a, b) => b.score - a.score);
  const relevant = scored.filter(s => s.score > 0).map(s => s.chunk);

  if (relevant.length === 0) {
    // Return standard foundation texts if no specific topic was matched
    return VERIFIED_KNOWLEDGE_BASE.slice(0, maxResults);
  }

  return relevant.slice(0, maxResults);
}
