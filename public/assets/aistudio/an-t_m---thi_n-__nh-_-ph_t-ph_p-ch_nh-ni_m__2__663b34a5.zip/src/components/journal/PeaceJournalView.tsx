import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { JournalEntry, MoodType } from '../../types';
import {
  PenLine,
  Plus,
  Trash2,
  Calendar,
  Sparkles,
  Download,
  Search,
  CheckCircle2,
  Heart
} from 'lucide-react';

export const PeaceJournalView: React.FC = () => {
  const { user, token } = useAuth();
  const [entries, setEntries] = useState<JournalEntry[]>([]);
  const [isCreating, setIsCreating] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Form states
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [gratitude1, setGratitude1] = useState('');
  const [gratitude2, setGratitude2] = useState('');
  const [gratitude3, setGratitude3] = useState('');
  const [mood, setMood] = useState<MoodType>('peaceful');

  const prompts = [
    'Hôm nay điều gì khiến bạn mỉm cười?',
    'Ba điều bạn cảm thấy biết ơn lúc này là gì?',
    'Điều gì bạn muốn buông bỏ để tâm hồn nhẹ nhõm hơn?',
    'Khoảnh khắc nào trong ngày mang lại cho bạn sự bình an?'
  ];

  // Fetch journal entries
  useEffect(() => {
    const fetchEntries = async () => {
      try {
        const res = await fetch('/api/user/journal', {
          headers: token ? { Authorization: `Bearer ${token}` } : {}
        });
        const data = await res.json();
        if (data.entries) setEntries(data.entries);
      } catch (e) {
        // Fallback local storage
        const saved = localStorage.getItem('antam_journals');
        if (saved) setEntries(JSON.parse(saved));
      }
    };
    fetchEntries();
  }, [user, token]);

  const handleSaveEntry = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title && !content) return;

    const gratitudeItems = [gratitude1, gratitude2, gratitude3].filter(g => g.trim().length > 0);

    const payload = {
      title: title || 'Khoảnh khắc bình an',
      content,
      gratitudeItems,
      mood,
      tags: ['an_tam', mood]
    };

    try {
      const res = await fetch('/api/user/journal', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {})
        },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (data.entry) {
        setEntries([data.entry, ...entries]);
      }
    } catch (e) {
      const newEntry: JournalEntry = {
        id: `local-${Date.now()}`,
        title: title || 'Khoảnh khắc bình an',
        content,
        gratitudeItems,
        mood,
        tags: ['an_tam'],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      const updated = [newEntry, ...entries];
      setEntries(updated);
      localStorage.setItem('antam_journals', JSON.stringify(updated));
    }

    // Reset form
    setTitle('');
    setContent('');
    setGratitude1('');
    setGratitude2('');
    setGratitude3('');
    setIsCreating(false);
  };

  const handleDelete = async (id: string) => {
    setEntries(entries.filter(e => e.id !== id));
    try {
      await fetch(`/api/user/journal/${id}`, {
        method: 'DELETE',
        headers: token ? { Authorization: `Bearer ${token}` } : {}
      });
    } catch (e) {}
  };

  const handleExport = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(entries, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `antam_nhat_ky_${new Date().toISOString().split('T')[0]}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const filteredEntries = entries.filter(e =>
    e.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    e.content.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-6 pb-28 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-serif text-2xl sm:text-3xl font-bold text-[#101D35] dark:text-[#F5F7FA]">
            Nhật Ký Bình An
          </h1>
          <p className="text-xs sm:text-sm text-[#17202D]/70 dark:text-white/70">
            Không gian lưu giữ lòng biết ơn, chiêm nghiệm và giải tỏa cảm xúc riêng tư
          </p>
        </div>

        <div className="flex items-center gap-2">
          {entries.length > 0 && (
            <button
              onClick={handleExport}
              className="px-3.5 py-2 rounded-xl bg-white/70 dark:bg-white/10 border border-[#E8DED0] dark:border-white/10 text-xs font-medium text-[#17202D]/70 dark:text-white/70 hover:text-[#101D35] transition-colors flex items-center gap-1.5 min-h-[44px]"
              title="Xuất nhật ký"
            >
              <Download className="w-4 h-4" />
              <span>Xuất dữ liệu</span>
            </button>
          )}

          <button
            onClick={() => setIsCreating(!isCreating)}
            className="px-4 py-2 rounded-xl bg-[#101D35] dark:bg-[#D8B878] text-white dark:text-[#101D35] text-xs font-semibold shadow-sm hover:opacity-95 transition-opacity flex items-center gap-1.5 min-h-[44px]"
          >
            {isCreating ? 'Đóng viết' : (
              <>
                <Plus className="w-4 h-4" />
                <span>Viết trang mới</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Editor Modal / Accordion */}
      {isCreating && (
        <form
          onSubmit={handleSaveEntry}
          className="p-6 rounded-3xl bg-white dark:bg-[#172644] border border-[#E8DED0] dark:border-white/10 shadow-lg space-y-4 animate-fadeIn"
        >
          <div className="flex items-center justify-between">
            <h3 className="font-serif text-lg font-bold text-[#101D35] dark:text-white">
              Ghi lại khoảnh khắc hôm nay
            </h3>
            {/* Mood selector */}
            <select
              value={mood}
              onChange={(e) => setMood(e.target.value as MoodType)}
              className="text-xs p-2 rounded-xl bg-[#E8DED0]/50 dark:bg-white/10 border-none outline-none font-medium cursor-pointer"
            >
              <option value="peaceful">🪷 Bình an</option>
              <option value="happy">✨ Vui vẻ</option>
              <option value="tired">🍃 Mệt mỏi</option>
              <option value="anxious">☁️ Lo lắng</option>
              <option value="stressed">⚡ Căng thẳng</option>
            </select>
          </div>

          <input
            type="text"
            placeholder="Tiêu đề trang nhật ký (ví dụ: Một buổi sáng dịu lành...)"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full px-4 py-2.5 rounded-xl bg-black/5 dark:bg-white/5 border border-transparent focus:border-[#D8B878] text-sm focus:outline-none transition-colors"
          />

          {/* 3 Gratitude points */}
          <div className="p-4 rounded-2xl bg-[#D8B878]/10 border border-[#D8B878]/25 space-y-2">
            <div className="flex items-center gap-1.5 text-xs font-semibold text-[#B89650] dark:text-[#D8B878]">
              <Heart className="w-3.5 h-3.5 fill-current" />
              <span>3 điều bạn biết ơn lúc này:</span>
            </div>
            <input
              type="text"
              placeholder="1. Ví dụ: Một hơi thở bình yên..."
              value={gratitude1}
              onChange={(e) => setGratitude1(e.target.value)}
              className="w-full px-3 py-1.5 text-xs rounded-lg bg-white/80 dark:bg-black/20 border border-transparent focus:outline-none focus:border-[#D8B878]"
            />
            <input
              type="text"
              placeholder="2. Ví dụ: Lời hỏi thăm từ một người bạn..."
              value={gratitude2}
              onChange={(e) => setGratitude2(e.target.value)}
              className="w-full px-3 py-1.5 text-xs rounded-lg bg-white/80 dark:bg-black/20 border border-transparent focus:outline-none focus:border-[#D8B878]"
            />
            <input
              type="text"
              placeholder="3. Ví dụ: Ly nước mát sau ngày làm việc..."
              value={gratitude3}
              onChange={(e) => setGratitude3(e.target.value)}
              className="w-full px-3 py-1.5 text-xs rounded-lg bg-white/80 dark:bg-black/20 border border-transparent focus:outline-none focus:border-[#D8B878]"
            />
          </div>

          <textarea
            rows={4}
            placeholder="Tâm sự, suy ngẫm hoặc điều bạn muốn buông bỏ hôm nay..."
            value={content}
            onChange={(e) => setContent(e.target.value)}
            className="w-full p-4 rounded-xl bg-black/5 dark:bg-white/5 border border-transparent focus:border-[#D8B878] text-sm focus:outline-none transition-colors leading-relaxed"
          />

          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={() => setIsCreating(false)}
              className="px-4 py-2 text-xs font-medium text-[#17202D]/60 dark:text-white/60 hover:text-[#101D35] min-h-[40px]"
            >
              Hủy
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-[#101D35] dark:bg-[#D8B878] text-white dark:text-[#101D35] text-xs font-semibold hover:opacity-95 shadow-sm min-h-[40px]"
            >
              Lưu vào nhật ký
            </button>
          </div>
        </form>
      )}

      {/* Search Input */}
      {entries.length > 0 && (
        <div className="relative max-w-md">
          <Search className="w-4 h-4 absolute left-3.5 top-3.5 text-[#17202D]/40 dark:text-white/40" />
          <input
            type="text"
            placeholder="Tìm kiếm dòng nhật ký..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-white/70 dark:bg-white/5 border border-[#E8DED0] dark:border-white/10 text-xs sm:text-sm focus:outline-none focus:border-[#D8B878]"
          />
        </div>
      )}

      {/* Entries List */}
      <div className="space-y-4">
        {filteredEntries.map((entry) => (
          <div
            key={entry.id}
            className="p-6 rounded-3xl bg-white/80 dark:bg-white/5 border border-[#E8DED0] dark:border-white/10 shadow-sm space-y-3"
          >
            <div className="flex items-start justify-between gap-4">
              <div>
                <span className="text-[11px] text-[#17202D]/50 dark:text-white/50 flex items-center gap-1 mb-1">
                  <Calendar className="w-3.5 h-3.5" />
                  <span>{new Date(entry.createdAt).toLocaleDateString('vi-VN', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</span>
                </span>
                <h3 className="font-serif text-lg font-bold text-[#101D35] dark:text-white">
                  {entry.title}
                </h3>
              </div>

              <button
                onClick={() => handleDelete(entry.id)}
                className="p-2 text-[#17202D]/40 dark:text-white/40 hover:text-rose-500 rounded-lg transition-colors min-h-[40px] min-w-[40px] flex items-center justify-center"
                title="Xóa trang nhật ký"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>

            {/* Gratitude tags */}
            {entry.gratitudeItems && entry.gratitudeItems.length > 0 && (
              <div className="p-3 rounded-2xl bg-[#D8B878]/10 border border-[#D8B878]/20 space-y-1">
                <span className="text-[11px] font-semibold text-[#B89650] dark:text-[#D8B878] block">
                  Những điều biết ơn:
                </span>
                <ul className="text-xs text-[#17202D]/80 dark:text-white/80 space-y-0.5 list-disc list-inside">
                  {entry.gratitudeItems.map((g, i) => (
                    <li key={i}>{g}</li>
                  ))}
                </ul>
              </div>
            )}

            {entry.content && (
              <p className="text-xs sm:text-sm text-[#17202D]/80 dark:text-white/80 whitespace-pre-line leading-relaxed">
                {entry.content}
              </p>
            )}
          </div>
        ))}

        {entries.length === 0 && !isCreating && (
          <div className="p-12 text-center rounded-3xl bg-white/40 dark:bg-white/5 border border-dashed border-[#E8DED0] dark:border-white/10 space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-[#D8B878]/20 text-[#B89650] dark:text-[#D8B878] flex items-center justify-center mx-auto">
              <PenLine className="w-6 h-6" />
            </div>
            <h4 className="font-serif text-base font-bold text-[#101D35] dark:text-white">
              Chưa có trang nhật ký nào
            </h4>
            <p className="text-xs text-[#17202D]/60 dark:text-white/60 max-w-sm mx-auto">
              Hãy bắt đầu bằng việc ghi lại một điều nhỏ bé khiến bạn mỉm cười hôm nay để tưới tẩm hạt giống bình an.
            </p>
            <button
              onClick={() => setIsCreating(true)}
              className="px-4 py-2 rounded-xl bg-[#101D35] dark:bg-[#D8B878] text-white dark:text-[#101D35] text-xs font-semibold"
            >
              Viết dòng đầu tiên
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
