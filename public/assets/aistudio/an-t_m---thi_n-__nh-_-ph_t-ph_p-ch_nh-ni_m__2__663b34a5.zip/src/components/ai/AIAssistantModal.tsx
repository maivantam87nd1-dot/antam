import React, { useState, useRef, useEffect } from 'react';
import { AIMessage } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { useAudio } from '../../context/AudioContext';
import { MEDITATION_TRACKS } from '../../data/mockData';
import {
  X,
  Send,
  Sparkles,
  Bot,
  User,
  ArrowRight,
  ShieldCheck,
  RefreshCw,
  Mic,
  MicOff,
  BookMarked
} from 'lucide-react';

interface AIAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenBreathing: () => void;
  onOpenBuddhist: () => void;
}

export const AIAssistantModal: React.FC<AIAssistantModalProps> = ({
  isOpen,
  onClose,
  onOpenBreathing,
  onOpenBuddhist
}) => {
  const { user, token } = useAuth();
  const { playTrack } = useAudio();

  const [messages, setMessages] = useState<AIMessage[]>([
    {
      id: 'init-1',
      role: 'assistant',
      content: `Kính chào bạn ${user?.name || ''}. Tôi là Trợ Lý Chánh Niệm & Phật Pháp AN TÂM. Tôi được trau dồi dựa trên các kinh điển Phật học đã được kiểm chứng và kiến thức thiền định chính thống. Bạn đang cảm thấy thế nào, hay có thắc mắc Phật pháp nào muốn cùng tôi chiêm nghiệm?`,
      timestamp: new Date().toISOString(),
      citations: ['Kinh Chuyển Pháp Luân', 'Bát Nhã Tâm Kinh', 'Kinh Quán Niệm Hơi Thở']
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);

  const quickPrompts = [
    'Tứ Diệu Đế và Bát Chánh Đạo là gì?',
    'Ý nghĩa câu "Sắc tức thị không" trong Tâm Kinh?',
    'Làm sao để thực hành buông bỏ khi lòng còn vướng bận?',
    'Tôi khó ngủ và lo lắng, hãy hướng dẫn tôi thở',
    'Luật Nhân Quả vận hành như thế nào trong đời sống?'
  ];

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isSending]);

  // Initialize Speech Recognition if supported
  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.lang = 'vi-VN';
      recognition.interimResults = false;

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInputText(prev => (prev ? prev + ' ' + transcript : transcript));
        setIsListening(false);
      };

      recognition.onerror = () => {
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
    }
  }, []);

  if (!isOpen) return null;

  const toggleVoiceInput = () => {
    if (!recognitionRef.current) {
      alert('Trình duyệt của bạn chưa hỗ trợ nhận diện giọng nói tiếng Việt trực tiếp.');
      return;
    }

    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      try {
        recognitionRef.current.start();
        setIsListening(true);
      } catch (e) {
        setIsListening(false);
      }
    }
  };

  const handleSendMessage = async (textToSend?: string) => {
    const content = textToSend || inputText;
    if (!content.trim() || isSending) return;

    const userMsg: AIMessage = {
      id: `u-${Date.now()}`,
      role: 'user',
      content,
      timestamp: new Date().toISOString()
    };

    const newMessages = [...messages, userMsg];
    setMessages(newMessages);
    setInputText('');
    setIsSending(false);

    try {
      setIsSending(true);
      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {})
        },
        body: JSON.stringify({
          messages: newMessages.map(m => ({ role: m.role, content: m.content })),
        })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Lỗi xử lý AI.');
      }

      const aiMsg: AIMessage = {
        id: `ai-${Date.now()}`,
        role: 'assistant',
        content: data.reply || 'An Tâm đang cùng bạn an trú trong sự tĩnh lặng...',
        timestamp: new Date().toISOString(),
        citations: data.citations || [],
        suggestedAction: data.suggestedAction
      };
      setMessages([...newMessages, aiMsg]);
    } catch (e: any) {
      const fallbackMsg: AIMessage = {
        id: `ai-${Date.now()}`,
        role: 'assistant',
        content: e.message || 'An Tâm luôn ở bên bạn. Khi tâm trí xao động, điều tốt nhất lúc này là quay về với hơi thở tự nhiên. Bạn hãy thở vào một hơi thật sâu và thở ra buông bỏ muộn phiền nhé.',
        timestamp: new Date().toISOString(),
        citations: ['Kinh Quán Niệm Hơi Thở (Ānāpānasati Sutta)'],
        suggestedAction: {
          type: 'breathing',
          targetId: 'relax',
          label: 'Tập thở thư giãn 4-6 nhịp'
        }
      };
      setMessages([...newMessages, fallbackMsg]);
    } finally {
      setIsSending(false);
    }
  };

  const handleExecuteAction = (action: any) => {
    onClose();
    if (action.type === 'breathing') {
      onOpenBreathing();
    } else if (action.type === 'scripture') {
      onOpenBuddhist();
    } else if (action.type === 'meditation') {
      const track = MEDITATION_TRACKS.find(t => t.id === action.targetId) || MEDITATION_TRACKS[0];
      playTrack(track);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-0 sm:p-4 bg-black/75 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
    >
      <div className="relative w-full max-w-2xl h-full sm:h-[86vh] bg-[#F8F6F1] dark:bg-[#101D35] text-[#17202D] dark:text-[#F5F7FA] rounded-none sm:rounded-3xl shadow-2xl border border-[#E8DED0] dark:border-white/10 flex flex-col overflow-hidden">
        {/* Top bar */}
        <div className="p-4 border-b border-[#E8DED0] dark:border-white/10 flex items-center justify-between bg-white/60 dark:bg-black/20">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#D8B878]/25 text-[#B89650] dark:text-[#D8B878] flex items-center justify-center shadow-sm">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-serif text-base font-bold text-[#101D35] dark:text-white flex items-center gap-1.5">
                <span>AN TÂM AI · Trợ Lý Phật Pháp & Chánh Niệm</span>
                <span className="text-[10px] font-sans px-2 py-0.5 rounded-full bg-[#D8B878]/20 text-[#B89650] dark:text-[#D8B878] font-bold">
                  RAG
                </span>
              </h3>
              <p className="text-[11px] text-[#17202D]/60 dark:text-white/60">
                Truy xuất kinh điển chính thống & đồng hành chữa lành tinh thần
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-black/5 dark:hover:bg-white/10 transition-colors min-h-[44px] min-w-[44px] flex items-center justify-center"
            title="Đóng"
            aria-label="Đóng"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Messages Feed */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((m) => {
            const isAi = m.role === 'assistant';
            return (
              <div
                key={m.id}
                className={`flex gap-3 ${isAi ? 'justify-start' : 'justify-end'}`}
              >
                {isAi && (
                  <div className="w-8 h-8 rounded-full bg-[#D8B878]/20 text-[#B89650] dark:text-[#D8B878] flex items-center justify-center shrink-0 mt-1">
                    <Bot className="w-4 h-4" />
                  </div>
                )}

                <div className="max-w-[85%] space-y-2">
                  <div
                    className={`p-4 rounded-3xl text-xs sm:text-sm leading-relaxed ${
                      isAi
                        ? 'bg-white dark:bg-[#172644] text-[#17202D] dark:text-[#F5F7FA] border border-[#E8DED0] dark:border-white/10 shadow-sm'
                        : 'bg-[#101D35] text-white dark:bg-[#D8B878] dark:text-[#101D35] font-medium'
                    }`}
                  >
                    <p className="whitespace-pre-line">{m.content}</p>

                    {/* Citations from verified RAG sources */}
                    {isAi && m.citations && m.citations.length > 0 && (
                      <div className="mt-3 pt-2 border-t border-[#E8DED0]/60 dark:border-white/10 text-[11px] text-[#17202D]/60 dark:text-white/60 flex items-start gap-1.5">
                        <BookMarked className="w-3.5 h-3.5 text-[#B89650] dark:text-[#D8B878] shrink-0 mt-0.5" />
                        <div>
                          <span className="font-semibold text-[#B89650] dark:text-[#D8B878]">Căn cứ kinh điển:</span>{' '}
                          <span>{m.citations.join(' · ')}</span>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Contextual Action Button from AI */}
                  {isAi && m.suggestedAction && (
                    <button
                      onClick={() => handleExecuteAction(m.suggestedAction)}
                      className="flex items-center gap-2 px-4 py-2 rounded-2xl bg-[#D8B878]/20 hover:bg-[#D8B878]/30 text-[#B89650] dark:text-[#D8B878] text-xs font-semibold border border-[#D8B878]/40 transition-colors shadow-sm"
                    >
                      <span>{m.suggestedAction.label}</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                {!isAi && (
                  <div className="w-8 h-8 rounded-full bg-[#101D35] dark:bg-[#D8B878] text-white dark:text-[#101D35] flex items-center justify-center shrink-0 mt-1">
                    <User className="w-4 h-4" />
                  </div>
                )}
              </div>
            );
          })}

          {isSending && (
            <div className="flex gap-3 items-center text-xs text-[#17202D]/60 dark:text-white/60 italic">
              <div className="w-8 h-8 rounded-full bg-[#D8B878]/20 text-[#B89650] dark:text-[#D8B878] flex items-center justify-center shrink-0">
                <RefreshCw className="w-4 h-4 animate-spin text-[#B89650]" />
              </div>
              <span>An Tâm đang tra cứu kinh tạng và chuẩn bị phản hồi...</span>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Quick Verified Prompts Carousel */}
        <div className="px-4 py-2 bg-white/40 dark:bg-black/10 border-t border-[#E8DED0] dark:border-white/10 flex items-center gap-2 overflow-x-auto scrollbar-none">
          {quickPrompts.map((q, idx) => (
            <button
              key={idx}
              onClick={() => handleSendMessage(q)}
              className="px-3 py-1.5 rounded-full bg-white dark:bg-white/5 border border-[#E8DED0] dark:border-white/10 text-[11px] text-[#17202D]/70 dark:text-white/70 hover:border-[#D8B878] whitespace-nowrap transition-colors min-h-[32px]"
            >
              {q}
            </button>
          ))}
        </div>

        {/* Input Form with Voice Button */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage();
          }}
          className="p-3 bg-white dark:bg-[#172644] border-t border-[#E8DED0] dark:border-white/10 flex items-center gap-2"
        >
          <button
            type="button"
            onClick={toggleVoiceInput}
            className={`p-3 rounded-2xl transition-all min-h-[44px] min-w-[44px] flex items-center justify-center ${
              isListening
                ? 'bg-rose-500 text-white animate-pulse'
                : 'bg-black/5 dark:bg-white/10 text-[#17202D]/70 dark:text-white/70 hover:text-[#101D35]'
            }`}
            title={isListening ? 'Dừng lắng nghe' : 'Hỏi bằng giọng nói (Micro)'}
          >
            {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
          </button>

          <input
            type="text"
            placeholder={isListening ? 'Đang lắng nghe bạn nói...' : 'Hỏi đáp Phật pháp, thiền định hoặc chia sẻ cảm xúc...'}
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            disabled={isSending}
            className="flex-1 px-4 py-3 rounded-2xl bg-[#F8F6F1] dark:bg-black/20 border border-transparent focus:border-[#D8B878] text-xs sm:text-sm focus:outline-none transition-colors"
          />

          <button
            type="submit"
            disabled={!inputText.trim() || isSending}
            className="p-3 rounded-2xl bg-[#101D35] dark:bg-[#D8B878] text-white dark:text-[#101D35] hover:opacity-95 disabled:opacity-40 transition-opacity min-h-[44px] min-w-[44px] flex items-center justify-center shadow-sm"
            title="Gửi câu hỏi"
            aria-label="Gửi"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>

        {/* Safety Disclaimer Footer */}
        <div className="px-4 py-2 bg-black/5 dark:bg-black/30 text-[10px] text-center text-[#17202D]/50 dark:text-white/50 flex items-center justify-center gap-1.5">
          <ShieldCheck className="w-3.5 h-3.5 text-[#B89650]" />
          <span>Thông tin được kiểm chứng từ kinh điển. Không thay thế tư vấn y khoa hoặc điều trị tâm lý chuyên nghiệp.</span>
        </div>
      </div>
    </div>
  );
};
