import React from 'react';
import { useAudio } from '../../context/AudioContext';
import { AMBIENT_SOUNDS, SOUND_MIX_PRESETS } from '../../data/mockData';
import {
  CloudRain,
  Waves,
  Bell,
  Radio,
  Volume2,
  VolumeX,
  Moon,
  RotateCcw,
  Sparkles
} from 'lucide-react';

export const SoundMixerView: React.FC = () => {
  const {
    ambientVolumes,
    setAmbientVolume,
    sleepTimerMinutes,
    setSleepTimer,
  } = useAudio();

  const getSoundIcon = (id: string) => {
    switch (id) {
      case 'rain':
        return CloudRain;
      case 'stream':
        return Waves;
      case 'singing_bowl':
        return Bell;
      case 'theta_drone':
        return Radio;
      default:
        return Bell;
    }
  };

  const handleApplyPreset = (preset: typeof SOUND_MIX_PRESETS[0]) => {
    Object.entries(preset.volumes).forEach(([id, vol]) => {
      setAmbientVolume(id, vol);
    });
  };

  const handleResetAll = () => {
    AMBIENT_SOUNDS.forEach((s) => {
      setAmbientVolume(s.id, 0);
    });
  };

  const isAnyPlaying = Object.values(ambientVolumes).some(v => v > 0);

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-6 pb-28 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-serif text-2xl sm:text-3xl font-bold text-[#101D35] dark:text-[#F5F7FA]">
            Phòng Âm Thanh & Giấc Ngủ
          </h1>
          <p className="text-xs sm:text-sm text-[#17202D]/70 dark:text-white/70">
            Hòa quyện âm thanh tự nhiên, chuông thiền và sóng não thư giãn sâu
          </p>
        </div>

        {isAnyPlaying && (
          <button
            onClick={handleResetAll}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-black/5 dark:bg-white/10 text-xs font-medium text-[#17202D]/70 dark:text-white/70 hover:text-rose-500 transition-colors self-start min-h-[36px]"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Tắt tất cả âm thanh</span>
          </button>
        )}
      </div>

      {/* Preset Soundscapes */}
      <div className="space-y-3">
        <span className="text-xs font-semibold text-[#B89650] dark:text-[#D8B878] uppercase tracking-wider block">
          Bộ Phối Âm Thiết Lập Sẵn
        </span>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {SOUND_MIX_PRESETS.map((p) => (
            <button
              key={p.id}
              onClick={() => handleApplyPreset(p)}
              className="p-4 rounded-2xl bg-white/80 dark:bg-white/5 border border-[#E8DED0] dark:border-white/10 hover:border-[#D8B878] text-left transition-all hover:shadow-sm group"
            >
              <div className="flex items-center gap-2 mb-1">
                <Sparkles className="w-4 h-4 text-[#B89650] dark:text-[#D8B878]" />
                <h4 className="text-sm font-bold text-[#101D35] dark:text-white group-hover:text-[#B89650] dark:group-hover:text-[#D8B878] transition-colors">
                  {p.name}
                </h4>
              </div>
              <p className="text-xs text-[#17202D]/60 dark:text-white/60 line-clamp-2">
                {p.description}
              </p>
            </button>
          ))}
        </div>
      </div>

      {/* Multi-Track Mixer Channels */}
      <div className="space-y-4">
        <span className="text-xs font-semibold text-[#B89650] dark:text-[#D8B878] uppercase tracking-wider block">
          Bàn Trộn Âm Thanh Đa Tầng (Sound Mixer)
        </span>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {AMBIENT_SOUNDS.map((sound) => {
            const Icon = getSoundIcon(sound.id);
            const volume = ambientVolumes[sound.id] || 0;
            const isPlaying = volume > 0;

            return (
              <div
                key={sound.id}
                className={`p-5 rounded-3xl bg-white/80 dark:bg-white/5 border transition-all ${
                  isPlaying
                    ? 'border-[#D8B878] shadow-sm'
                    : 'border-[#E8DED0] dark:border-white/10'
                }`}
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-10 h-10 rounded-2xl flex items-center justify-center transition-colors ${
                        isPlaying
                          ? 'bg-[#101D35] text-[#D8B878] dark:bg-[#D8B878] dark:text-[#101D35]'
                          : 'bg-black/5 dark:bg-white/10 text-[#17202D]/60 dark:text-white/60'
                      }`}
                    >
                      <Icon className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-[#101D35] dark:text-white">
                        {sound.name}
                      </h4>
                      <span className="text-[11px] text-[#17202D]/50 dark:text-white/50 capitalize">
                        {sound.category === 'nature'
                          ? 'Thiên nhiên'
                          : sound.category === 'meditation'
                          ? 'Chuông thiền'
                          : 'Sóng não'}
                      </span>
                    </div>
                  </div>

                  <span className="font-mono text-xs font-semibold text-[#B89650] dark:text-[#D8B878] tabular-nums">
                    {Math.round(volume * 100)}%
                  </span>
                </div>

                {/* Slider */}
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setAmbientVolume(sound.id, isPlaying ? 0 : sound.defaultVolume)}
                    className="p-1.5 text-[#17202D]/50 dark:text-white/50 hover:text-[#101D35] dark:hover:text-white transition-colors min-h-[36px] min-w-[36px] flex items-center justify-center"
                    title={isPlaying ? 'Tắt' : 'Bật nhanh'}
                  >
                    {isPlaying ? <Volume2 className="w-4 h-4 text-[#B89650]" /> : <VolumeX className="w-4 h-4" />}
                  </button>

                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.05"
                    value={volume}
                    onChange={(e) => setAmbientVolume(sound.id, parseFloat(e.target.value))}
                    className="w-full h-2 bg-[#E8DED0] dark:bg-white/15 rounded-lg appearance-none cursor-pointer accent-[#D8B878]"
                    aria-label={`Âm lượng ${sound.name}`}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Sleep Timer Section */}
      <div className="p-6 rounded-3xl bg-white/80 dark:bg-white/5 border border-[#E8DED0] dark:border-white/10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
            <Moon className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-[#101D35] dark:text-white">
              Hẹn Giờ Tự Động Tắt
            </h4>
            <p className="text-xs text-[#17202D]/60 dark:text-white/60">
              Âm lượng sẽ tự động giảm dần êm ái trong 30 giây cuối trước khi dừng hoàn toàn.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5 flex-wrap">
          {[5, 15, 30, 45, 60].map((m) => (
            <button
              key={m}
              onClick={() => setSleepTimer(sleepTimerMinutes === m ? null : m)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-xl transition-all min-h-[36px] ${
                sleepTimerMinutes === m
                  ? 'bg-[#101D35] text-white dark:bg-[#D8B878] dark:text-[#101D35] shadow-sm'
                  : 'bg-black/5 dark:bg-white/10 text-[#17202D]/70 dark:text-white/70 hover:bg-black/10'
              }`}
            >
              {m} phút
            </button>
          ))}
          {sleepTimerMinutes !== null && (
            <button
              onClick={() => setSleepTimer(null)}
              className="px-2.5 py-1.5 text-xs text-rose-500 hover:underline min-h-[36px]"
            >
              Hủy
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
