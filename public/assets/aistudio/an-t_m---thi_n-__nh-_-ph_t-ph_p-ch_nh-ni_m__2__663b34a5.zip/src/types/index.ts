export type MoodType = 'peaceful' | 'happy' | 'tired' | 'anxious' | 'sad' | 'stressed' | 'insomnia';

export interface MoodCheckin {
  id: string;
  mood: MoodType;
  label: string;
  note?: string;
  timestamp: string;
}

export type MeditationCategory =
  | 'beginner'
  | 'morning'
  | 'sleep'
  | 'relaxation'
  | 'breath_focus'
  | 'mindfulness'
  | 'gratitude'
  | 'loving_kindness'
  | 'letting_go'
  | 'focus'
  | 'walking'
  | 'silent';

export interface MeditationTrack {
  id: string;
  title: string;
  subtitle: string;
  category: MeditationCategory;
  categoryName: string;
  description: string;
  durations: number[]; // e.g. [3, 5, 10, 15, 20, 30] in minutes
  instructor: string;
  source: string;
  image: string;
  audioTone: 'singing_bowl' | 'rain' | 'stream' | 'theta' | 'bamboo';
  isPremium?: boolean;
  instructions: string[];
}

export interface BuddhistScripture {
  id: string;
  title: string;
  sanskritTitle?: string;
  category: 'sutra' | 'mantra' | 'dharma_talk' | 'stories' | 'teachings';
  categoryLabel: string;
  translator: string;
  source: string;
  contentType: 'original' | 'translation' | 'commentary';
  description: string;
  image: string;
  audioTone: 'singing_bowl' | 'stream';
  contentVerses: {
    sectionTitle?: string;
    original?: string;
    translation: string;
    explanation?: string;
  }[];
  isPremium?: boolean;
}

export interface AmbientSound {
  id: string;
  name: string;
  icon: string;
  category: 'nature' | 'meditation' | 'binaural';
  type: 'rain' | 'stream' | 'singing_bowl' | 'bamboo_wind' | 'waves' | 'theta_drone';
  defaultVolume: number;
}

export interface SoundMixPreset {
  id: string;
  name: string;
  description: string;
  volumes: Record<string, number>;
}

export interface MindfulnessSpace {
  id: string;
  name: string;
  vietnameseName: string;
  description: string;
  image: string;
  ambientTone: 'stream' | 'rain' | 'singing_bowl' | 'bamboo';
}

export interface MindfulnessJourney {
  id: string;
  title: string;
  subtitle: string;
  durationDays: number;
  description: string;
  image: string;
  steps: {
    day: number;
    title: string;
    description: string;
    meditationId: string;
    reflectionPrompt: string;
  }[];
}

export interface JournalEntry {
  id: string;
  title: string;
  content: string;
  gratitudeItems: string[];
  mood: MoodType;
  tags: string[];
  createdAt: string;
  updatedAt: string;
}

export interface UserProfile {
  id: string;
  email: string;
  name: string;
  avatar?: string;
  isGuest: boolean;
  role: 'super_admin' | 'admin' | 'editor' | 'user';
  isPremium: boolean;
  totalMeditationMinutes: number;
  totalSessions: number;
  streakDays: number;
  lastPracticeDate?: string;
  selectedGoals: string[];
  mindfulnessBell: {
    enabled: boolean;
    times: string[]; // e.g. ["08:00", "12:00", "18:00", "21:00"]
    sound: 'singing_bowl' | 'temple_bell';
  };
  theme: 'light' | 'dark' | 'system';
  fontSize: 'normal' | 'large' | 'extra_large';
  token?: string;
}

export interface KnowledgeChunk {
  id: string;
  documentTitle: string;
  tradition: string;
  source: string;
  chapter?: string;
  content: string;
  keywords: string[];
}

export interface SubscriptionEntitlement {
  id: string;
  userId: string;
  planId: 'monthly' | 'yearly';
  status: 'active' | 'expired' | 'trial' | 'revoked';
  expiresAt: string;
  receiptToken: string;
  platform: 'apple_storekit' | 'google_play' | 'sandbox_test';
  verifiedAt: string;
}

export interface AIMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: string;
  citations?: string[];
  suggestedAction?: {
    type: 'meditation' | 'breathing' | 'sound' | 'scripture';
    targetId: string;
    label: string;
  };
}

export interface ScriptureExplanation {
  scriptureId: string;
  verseIndex: number;
  mode: 'simple' | 'deep' | 'practical';
  explanation: string;
  traditionNotes?: string;
  practicalApplication?: string;
  citations: string[];
}

export interface AffiliateOffer {
  id: string;
  title: string;
  category: 'gối_thiền' | 'chuông_xoay' | 'sách_phật_học' | 'tinh_dầu' | 'trang_phục_thiền';
  categoryLabel: string;
  description: string;
  partnerName: string;
  priceVnd: number;
  formattedPrice: string;
  imageUrl: string;
  affiliateUrl: string;
  disclaimer: string;
  rating?: number;
  inStock: boolean;
  features: string[];
}

export interface AdRewardState {
  hasRewardedSession: boolean;
  rewardType: 'bonus_meditation' | 'deep_breathing' | 'soundscape';
  grantedAt?: string;
  expiresAt?: string;
}

export interface AdminAuditLog {
  id: string;
  action: string;
  adminEmail: string;
  timestamp: string;
  details: string;
}

export interface AdminAnalytics {
  totalUsers: number;
  totalPremium: number;
  totalMinutes: number;
  totalJournals: number;
  totalActiveSessions: number;
  totalAiRequests: number;
  activeToday: number;
  retentionD7: string;
  affiliateClicks: number;
  adImpressions: number;
}
